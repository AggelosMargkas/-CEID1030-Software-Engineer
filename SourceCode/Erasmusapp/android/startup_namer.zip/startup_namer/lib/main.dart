// Copyright 2018 The Flutter team. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:html';
import 'dart:ui';

import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: SplashPage()
  ));
}


class IconFont extends StatelessWidget{

  // Color color;
  // double size;
  // String iconName;
  //
  // IconFont({  this.color, this.size, this.iconName});

  @override
  Widget build(BuildContext context) {
    return Text('a',
    style: TextStyle(
      color: Colors.white,
      fontSize: 100,
      fontFamily: 'globe'
      )
    );

  }

}
class SplashPage extends StatelessWidget{

  @override
  Widget build(BuildContext context){

    return Scaffold(
      body: Container(
        color: Color(0xFF80C038),
        alignment: Alignment.center,
        child: IconFont(),
        // child: IconFont(
        //   color: Colors.white,
        //   size: 100,
        //   iconName: 'a',
        // ),

      )
    );
  }


}
